//
//  Cards.swift
//  Assessment 3
//
//  Created by Shalev on 10/21/15.
//  Copyright © 2015 Tedi Konda. All rights reserved.
//

import Foundation

struct Cards
{
    
}