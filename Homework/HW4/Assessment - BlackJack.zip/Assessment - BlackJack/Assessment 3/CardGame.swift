//
//  CardGame.swift
//  Assessment 3
//
//  Created by Tedi Konda on 1/23/15.
//  Copyright (c) 2015 Tedi Konda. All rights reserved.
//

import Foundation
protocol BlackJack {
    // Require a deal method
    // Require a first hand method
    func deal(toDealer: Bool)
    func firstHand()
    func startGame()
}

class CardGame: BlackJack {

    var human = Human(isDealer: false, cardScore: 0, visibleCards: [], name: "Keith", money: 100)
    var dealer = Dealer(isDealer: true, cardScore: 0, visibleCards: [], invisibleCard: 0, name: "Dealer")
    

    func startGame()
    {
        //start the game
        //create the players
        //let human = Player2(name: "keith", visibleCards: [""], money: 100)
        
//        print(self.human)
//        print(self.dealer)
        firstHand()
//        print(self.human)
//        print(self.dealer)
    }
    
    func deal(toDealer: Bool)
    {
        let random_card = Int(arc4random_uniform(13)) + 1
        if toDealer == true
        {
            if self.dealer.invisibleCard == 0
            {
                self.dealer.invisibleCard = random_card
            }
            else
            {
                self.dealer.visibleCards.append(random_card)
            }
        }
        else
        {
            if self.human.visibleCards.count == 0
            {
                self.human.visibleCards.append(1)
            }
            else
            {
                self.human.visibleCards.append(random_card)
            }
        }
//        print(human)
//        print(dealer)
    }
    
    func firstHand() {
        self.human.visibleCards = []
        self.dealer.visibleCards = []
        self.dealer.invisibleCard = 0
        for _ in 0...1
        {
            //first deal cards to Human
            deal(false)
            //deal cards to Dealer
            deal(true)
        }
    }
}