//
//  Player.swift
//  Assessment 3
//
//  Created by Tedi Konda on 1/23/15.
//  Copyright (c) 2015 Tedi Konda. All rights reserved.
//

import Foundation

//protocol playerOpts
//{
//    var name: String { get }
//    var isDealer: Bool { get }
//    var visibleCards: [String] { get set}
//    var money: Int { get set }
//}

/*
protocol CPU
{
    var invisibleCard: String { get }
}

protocol Human
{
    var name: String { get }
    var money: Int { get }
}

protocol Player
{
    var visibleCards: [String] { get set }
}

struct Player1: CPU, Player {
    var isDealer: Bool
    var visibleCards: [String]
    var invisibleCard: String
}

struct Player2: Human, Player
{
    var name: String
    var visibleCards: [String]
    var money: Int = 100
}*/

protocol Player
{
    var isDealer: Bool { get }
    var visibleCards: [Int] { get set }
    var name: String { get }
    var cardScore: Int { get set }
}

struct Dealer: Player
{
    var isDealer: Bool = true
    var cardScore: Int = 0
    var visibleCards: [Int]
//    {
//        didSet(newValue)
//        {
//            self.cardScore += newValue.last!
////            self.visibleCards.append(newValue)
////            self.cardScore += self.visibleCards.last!
//        }
//    }
    var invisibleCard: Int
    var name: String = "Dealer"
    
}

struct Human: Player
{
    var isDealer: Bool = false
    var cardScore: Int = 0
    var visibleCards: [Int]
    var name: String
    var money: Int
}