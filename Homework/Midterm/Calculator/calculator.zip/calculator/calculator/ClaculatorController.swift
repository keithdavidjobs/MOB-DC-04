//
//  ClaculatorController.swift
//  calculator
//
//  Created by Shalev on 10/30/15.
//  Copyright © 2015 Shalev. All rights reserved.
//

import UIKit

class ClaculatorController: UIViewController {

    let plusButton = UIButton()
    let minusButton = UIButton()
    let mulitplyButton = UIButton()
    let divideButton = UIButton()
    let equalsButton = UIButton()
    let percentButton = UIButton()
    let signButton = UIButton()
    let ACButton = UIButton()
    let numberButtons = [UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton()]
    let decimalButton = UIButton()
    let resultsLabel = UILabel()
//    let button0 = UIButton()
//    let button1 = UIButton()

    var decimalPushed: Bool = false
    var initialNumber: Float = 0
    var initialNumbersArray: [String] = []
    var secondNumber: Float = 0
    var secondNumbersArray: [String] = []
    var operatorSelected: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let mainButtonWidth = self.view.frame.size.width / 4
        let mainButtonHeight = self.view.frame.size.height / 7
        
        self.view.backgroundColor = UIColor.blackColor()
        
        self.resultsLabel.frame = CGRectMake(0, 0, self.view.frame.size.width, mainButtonHeight * 2)
        self.resultsLabel.backgroundColor = UIColor.blackColor()
        self.resultsLabel.textColor = UIColor.whiteColor()
        self.resultsLabel.textAlignment = NSTextAlignment.Right
        
        //1st row
        self.ACButton.frame = CGRectMake(0, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.ACButton.backgroundColor = UIColor.init(red: 0.43, green: 0.44, blue: 0.47, alpha: 1)
        self.ACButton.setTitle("AC", forState: .Normal)
        self.ACButton.layer.borderWidth = 1
        self.ACButton.addTarget(self, action: "clearAll:", forControlEvents: UIControlEvents.TouchUpInside)
        
        
        self.signButton.frame = CGRectMake(mainButtonWidth, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.signButton.backgroundColor = UIColor.init(red: 0.43, green: 0.44, blue: 0.47, alpha: 1)
        self.signButton.setTitle("+/-", forState: .Normal)
        self.signButton.layer.borderWidth = 1
        self.signButton.addTarget(self, action: "changeSign:", forControlEvents: UIControlEvents.TouchUpInside)
        
        self.percentButton.frame = CGRectMake(mainButtonWidth * 2, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.percentButton.backgroundColor = UIColor.init(red: 0.43, green: 0.44, blue: 0.47, alpha: 1)
        self.percentButton.setTitle("%", forState: .Normal)
        self.percentButton.layer.borderWidth = 1
        self.percentButton.addTarget(self, action: "percent:", forControlEvents: UIControlEvents.TouchUpInside)
        
        self.divideButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.divideButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
        self.divideButton.setTitle("/", forState: UIControlState.Normal)
        self.divideButton.layer.borderWidth = 1
        self.divideButton.addTarget(self, action: "divide:", forControlEvents: UIControlEvents.TouchUpInside)
        
        //right column
        self.mulitplyButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 3, mainButtonWidth, mainButtonHeight)
        self.mulitplyButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
        self.mulitplyButton.setTitle("X", forState: .Normal)
        self.mulitplyButton.layer.borderWidth = 1
        self.mulitplyButton.addTarget(self, action: "multiply:", forControlEvents: UIControlEvents.TouchUpInside)
        
        self.minusButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 4, mainButtonWidth, mainButtonHeight)
        self.minusButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
        self.minusButton.setTitle("-", forState: .Normal)
        self.minusButton.layer.borderWidth = 1
        self.minusButton.addTarget(self, action: "minus:", forControlEvents: UIControlEvents.TouchUpInside)
        
        self.plusButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 5, mainButtonWidth, mainButtonHeight)
        self.plusButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
        self.plusButton.setTitle("+", forState: .Normal)
        self.plusButton.layer.borderWidth = 1
        self.plusButton.addTarget(self, action: "plus:", forControlEvents: UIControlEvents.TouchUpInside)
        
        self.equalsButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 6, mainButtonWidth, mainButtonHeight)
        self.equalsButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
        self.equalsButton.setTitle("=", forState: .Normal)
        self.equalsButton.layer.borderWidth = 1
        self.equalsButton.addTarget(self, action: "equals:", forControlEvents: UIControlEvents.TouchUpInside)
        
        //the numbers
        for i in 0..<self.numberButtons.count
        {
            var tempWidth = mainButtonWidth
            var tempX: CGFloat = mainButtonWidth * CGFloat((i - 1) % 3)
            var tempY: CGFloat = 0
            if i == 0
            {
                //the button width is twice the size if it's the zero button
                tempWidth = mainButtonWidth * 2
                tempY = self.view.frame.height - mainButtonHeight
                tempX = 0
            }
            else if i < 4 && i > 0
            {
                tempY = self.view.frame.height - (mainButtonHeight * 2)
            }
            else if i < 7
            {
                tempY = self.view.frame.height - (mainButtonHeight * 3)
            }
            else
            {
                tempY = self.view.frame.height - (mainButtonHeight * 4)
            }
            self.numberButtons[i].frame = CGRectMake(tempX, tempY, tempWidth, mainButtonHeight)
            self.numberButtons[i].backgroundColor = UIColor.init(red: 0.6, green: 0.6, blue: 0.6, alpha: 1)
            self.numberButtons[i].setTitle("\(i)", forState: .Normal)
            self.numberButtons[i].addTarget(self, action: "pressNumber:", forControlEvents: UIControlEvents.TouchUpInside)
            self.numberButtons[i].layer.borderWidth = 1
            self.numberButtons[i].layer.cornerRadius = 5
            self.view.addSubview(self.numberButtons[i])
        }
        
        self.decimalButton.frame = CGRectMake(mainButtonWidth * 2, mainButtonHeight * 6, mainButtonWidth, mainButtonHeight)
        self.decimalButton.backgroundColor = UIColor.init(red: 0.6, green: 0.6, blue: 0.6, alpha: 1)
        self.decimalButton.setTitle(".", forState: .Normal)
        self.decimalButton.layer.borderWidth = 1
        self.decimalButton.addTarget(self, action: "pressDecimal:", forControlEvents: UIControlEvents.TouchUpInside)
        
        //grey
        //self.ACButton.backgroundColor = UIColor.init(red: 0.6, green: 0.6, blue: 0.6, alpha: 1)
        //orange
        //self.ACButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
        
        self.view.addSubview(self.ACButton)
        self.view.addSubview(self.signButton)
        self.view.addSubview(self.percentButton)
        self.view.addSubview(self.divideButton)
        self.view.addSubview(self.mulitplyButton)
        self.view.addSubview(self.minusButton)
        self.view.addSubview(self.plusButton)
        self.view.addSubview(self.equalsButton)
        self.view.addSubview(self.decimalButton)
        self.view.addSubview(self.resultsLabel)
        //self.view.addSubview(self.numberButtons[7])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pressNumber(sender: UIButton!)
    {
        if self.operatorSelected == "" && self.initialNumber == 0
        {
            print(sender.titleLabel?.text!)
            self.initialNumbersArray.append((sender.titleLabel?.text!)!)
            print(self.initialNumbersArray)
            self.resultsLabel.text = self.initialNumbersArray.joinWithSeparator("")
            self.initialNumber = (NSNumberFormatter().numberFromString(self.resultsLabel.text!)?.floatValue)!
        }
        else
        {
            self.secondNumbersArray.append((sender.titleLabel?.text)!)
            self.resultsLabel.text = self.secondNumbersArray.joinWithSeparator("")
            self.secondNumber = (NSNumberFormatter().numberFromString(self.resultsLabel.text!)?.floatValue)!
        }
        resetBorders()
//        self.resultsLabel.text = "hi"
    }
    
    func pressDecimal(sender: UIButton!)
    {
        print(".")
        if !self.decimalPushed
        {
            if self.operatorSelected == "" && self.initialNumber == 0
            {
                //first number
                if self.initialNumber > 0
                {
                    self.initialNumber = 0.0
                    self.initialNumbersArray = ["0", "."]
                }
                else
                {
                    self.initialNumbersArray.append(".")
                }
                self.resultsLabel.text = self.initialNumbersArray.joinWithSeparator("")
                self.initialNumber = (NSNumberFormatter().numberFromString(self.resultsLabel.text!)?.floatValue)!
            }
            else
            {
                //second number
                if self.secondNumber > 0
                {
                    self.secondNumber = 0.0
                    self.secondNumbersArray = ["0", "."]
                }
                else
                {
                    self.secondNumbersArray.append(".")
                }
                self.resultsLabel.text = self.secondNumbersArray.joinWithSeparator("")
                self.secondNumber = (NSNumberFormatter().numberFromString(self.resultsLabel.text!)?.floatValue)!
            }
            self.decimalPushed = true
        }
        resetBorders()
    }
    
    func plus(sender: UIButton!)
    {
        self.operatorSelected = "plus"
        self.decimalPushed = false
        sender.layer.borderWidth = 2
        if self.initialNumbersArray.count == 0
        {
            self.initialNumber = Float(self.resultsLabel.text!)!
            self.initialNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
        }
        else if self.initialNumbersArray.count > 0 && self.secondNumbersArray.count > 0
        {
            equals(sender)
            self.initialNumber = Float(self.resultsLabel.text!)!
            self.initialNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
        }
//        self.plusButton.layer.borderWidth = 2
    }
    
    func minus(sender: UIButton!)
    {
        self.operatorSelected = "minus"
        self.decimalPushed = false
        sender.layer.borderWidth = 2
        if self.initialNumbersArray.count == 0
        {
            self.initialNumber = Float(self.resultsLabel.text!)!
            self.initialNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
        }
    }
    
    func divide(sender: UIButton!)
    {
        self.operatorSelected = "divide"
        self.decimalPushed = false
        sender.layer.borderWidth = 2
        if self.initialNumbersArray.count == 0
        {
            self.initialNumber = Float(self.resultsLabel.text!)!
            self.initialNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
        }
    }
    
    func multiply(sender: UIButton!)
    {
        self.operatorSelected = "multiply"
        self.decimalPushed = false
        sender.layer.borderWidth = 2
        if self.initialNumbersArray.count == 0
        {
            self.initialNumber = Float(self.resultsLabel.text!)!
            self.initialNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
        }
    }
    
    func percent(sender: UIButton!)
    {
        if self.operatorSelected == ""
        {
            self.initialNumber /= 100
            self.resultsLabel.text = String(self.initialNumber)
            self.initialNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
            print(self.initialNumber)
        }
        else
        {
            self.secondNumber /= 100
            self.resultsLabel.text = String(self.secondNumber)
            self.secondNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
            print(self.secondNumber)
        }
    }
    
    func changeSign(sender: UIButton!)
    {
        if self.operatorSelected == ""
        {
            if self.initialNumber > 0
            {
                self.initialNumbersArray[0] = "-" + self.initialNumbersArray[0]
                self.initialNumber = self.initialNumber * -1
                self.resultsLabel.text = self.initialNumbersArray.joinWithSeparator("")
            }
            else
            {
                self.initialNumbersArray.append("-")
                self.resultsLabel.text = "-0"
            }
        }
        else
        {
            if self.secondNumber > 0
            {
                self.secondNumber = self.secondNumber * -1
                self.secondNumbersArray[0] = "-" + self.secondNumbersArray[0]
                self.resultsLabel.text = self.secondNumbersArray.joinWithSeparator("")
            }
            else
            {
                self.secondNumbersArray.append("-")
                self.resultsLabel.text = "-0"
            }
        }
    }
    
    func equals(sender: UIButton!)
    {
        switch self.operatorSelected
        {
            case "plus":
                print("add")
                let finalNum = (NSNumberFormatter().numberFromString(self.initialNumbersArray.joinWithSeparator(""))?.floatValue)! + (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
                //let finalNum = CGFloat(self.initialNumbersArray.joinWithSeparator("")) + Float(self.secondNumbersArray.joinWithSeparator(""))
                self.resultsLabel.text = String(finalNum)
//                self.initialNumber = (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
//                self.initialNumbersArray = self.secondNumbersArray
//                self.secondNumbersArray = []
//                self.secondNumber = 0
            case "minus":
                print("minus")
                let finalNum = (NSNumberFormatter().numberFromString(self.initialNumbersArray.joinWithSeparator(""))?.floatValue)! - (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
                self.resultsLabel.text = String(finalNum)
//                self.initialNumber = (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
//                self.initialNumbersArray = self.secondNumbersArray
//                self.secondNumbersArray = []
//                self.secondNumber = 0
            case "divide":
                print("divide")
                let finalNum = (NSNumberFormatter().numberFromString(self.initialNumbersArray.joinWithSeparator(""))?.floatValue)! / (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
                self.resultsLabel.text = String(finalNum)
//                self.initialNumber = (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
//                self.initialNumbersArray = self.secondNumbersArray
//                self.secondNumbersArray = []
//                self.secondNumber = 0
            case "multiply":
                print("multiply")
                let finalNum = (NSNumberFormatter().numberFromString(self.initialNumbersArray.joinWithSeparator(""))?.floatValue)! * (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
                self.resultsLabel.text = String(finalNum)
//                self.initialNumber = (NSNumberFormatter().numberFromString(self.secondNumbersArray.joinWithSeparator(""))?.floatValue)!
//                self.initialNumbersArray = self.secondNumbersArray
//                self.secondNumbersArray = []
//                self.secondNumber = 0
            default:
                print("nothing")
        }
        self.operatorSelected = ""
        self.initialNumber = 0
        self.initialNumbersArray = []
//        self.initialNumber = Float(self.resultsLabel.text!)!
//        self.initialNumbersArray = (self.resultsLabel.text?.componentsSeparatedByString(""))!
//        self.initialNumbersArray = self.resultsLabel.text?.characters.split("")
        print(self.initialNumbersArray)
        self.secondNumbersArray = []
        self.secondNumber = 0
        self.decimalPushed = false
    }
    
    func resetBorders()
    {
        self.plusButton.layer.borderWidth = 1
        self.minusButton.layer.borderWidth = 1
        self.mulitplyButton.layer.borderWidth = 1
        self.divideButton.layer.borderWidth = 1
    }
    
    func clearAll(sender: UIButton!)
    {
        self.initialNumber = 0
        self.initialNumbersArray = []
        self.secondNumber = 0
        self.secondNumbersArray = []
        self.decimalPushed = false
        self.operatorSelected = ""
        self.resultsLabel.text = ""
        resetBorders()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
