//
//  LaunchController.swift
//  calculator
//
//  Created by Shalev on 10/30/15.
//  Copyright © 2015 Shalev. All rights reserved.
//

import UIKit

class LaunchController: UIViewController {

    let plusButton = UIButton()
    let minusButton = UIButton()
    let mulitplyButton = UIButton()
    let divideButton = UIButton()
    let equalsButton = UIButton()
    let percentButton = UIButton()
    let signButton = UIButton()
    let ACButton = UIButton()
    let numberButtons = [UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton(), UIButton()]
    let decimalButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let mainButtonWidth = self.view.frame.size.width / 4
        let mainButtonHeight = self.view.frame.size.height / 7
        
        self.view.backgroundColor = UIColor.blackColor()
        
        
        //1st row
        self.ACButton.frame = CGRectMake(0, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.ACButton.backgroundColor = UIColor.init(red: 0.43, green: 0.44, blue: 0.47, alpha: 1)
//        self.ACButton.setTitle("AC", forState: .Normal)
        self.ACButton.layer.borderWidth = 1
        
        
        self.signButton.frame = CGRectMake(mainButtonWidth, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.signButton.backgroundColor = UIColor.init(red: 0.43, green: 0.44, blue: 0.47, alpha: 1)
//        self.signButton.setTitle("+/-", forState: .Normal)
        self.signButton.layer.borderWidth = 1
        
        self.percentButton.frame = CGRectMake(mainButtonWidth * 2, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.percentButton.backgroundColor = UIColor.init(red: 0.43, green: 0.44, blue: 0.47, alpha: 1)
//        self.percentButton.setTitle("%", forState: .Normal)
        self.percentButton.layer.borderWidth = 1
        
        self.divideButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 2, mainButtonWidth, mainButtonHeight)
        self.divideButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
//        self.divideButton.setTitle("/", forState: UIControlState.Normal)
        self.divideButton.layer.borderWidth = 1
        
        //right column
        self.mulitplyButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 3, mainButtonWidth, mainButtonHeight)
        self.mulitplyButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
//        self.mulitplyButton.setTitle("X", forState: .Normal)
        self.mulitplyButton.layer.borderWidth = 1
        
        self.minusButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 4, mainButtonWidth, mainButtonHeight)
        self.minusButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
//        self.minusButton.setTitle("-", forState: .Normal)
        self.minusButton.layer.borderWidth = 1
        
        self.plusButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 5, mainButtonWidth, mainButtonHeight)
        self.plusButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
//        self.plusButton.setTitle("+", forState: .Normal)
        self.plusButton.layer.borderWidth = 1
        
        self.equalsButton.frame = CGRectMake(mainButtonWidth * 3, mainButtonHeight * 6, mainButtonWidth, mainButtonHeight)
        self.equalsButton.backgroundColor = UIColor.init(red: 0.92, green: 0.51, blue: 0.16, alpha: 1)
//        self.equalsButton.setTitle("=", forState: .Normal)
        self.equalsButton.layer.borderWidth = 1
        
        //the numbers
        for i in 0..<self.numberButtons.count
        {
            var tempWidth = mainButtonWidth
            var tempX: CGFloat = mainButtonWidth * CGFloat((i - 1) % 3)
            var tempY: CGFloat = 0
            if i == 0
            {
                //the button width is twice the size if it's the zero button
                tempWidth = mainButtonWidth * 2
                tempY = self.view.frame.height - mainButtonHeight
                tempX = 0
            }
            else if i < 4 && i > 0
            {
                tempY = self.view.frame.height - (mainButtonHeight * 2)
            }
            else if i < 7
            {
                tempY = self.view.frame.height - (mainButtonHeight * 3)
            }
            else
            {
                tempY = self.view.frame.height - (mainButtonHeight * 4)
            }
            self.numberButtons[i].frame = CGRectMake(tempX, tempY, tempWidth, mainButtonHeight)
            self.numberButtons[i].backgroundColor = UIColor.init(red: 0.6, green: 0.6, blue: 0.6, alpha: 1)
            //self.numberButtons[i].setTitle("\(i)", forState: .Normal)
            self.numberButtons[i].layer.borderWidth = 1
            //self.numberButtons[i].layer.cornerRadius = 5
            self.view.addSubview(self.numberButtons[i])
        }
        
        self.decimalButton.frame = CGRectMake(mainButtonWidth * 2, mainButtonHeight * 6, mainButtonWidth, mainButtonHeight)
        self.decimalButton.backgroundColor = UIColor.init(red: 0.6, green: 0.6, blue: 0.6, alpha: 1)
        self.decimalButton.setTitle(".", forState: .Normal)
        self.decimalButton.layer.borderWidth = 1
        
        self.view.addSubview(self.ACButton)
        self.view.addSubview(self.signButton)
        self.view.addSubview(self.percentButton)
        self.view.addSubview(self.divideButton)
        self.view.addSubview(self.mulitplyButton)
        self.view.addSubview(self.minusButton)
        self.view.addSubview(self.plusButton)
        self.view.addSubview(self.equalsButton)
        self.view.addSubview(self.decimalButton)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
