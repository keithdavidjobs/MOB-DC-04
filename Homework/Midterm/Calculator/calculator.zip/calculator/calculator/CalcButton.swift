//
//  CalcButton.swift
//  calculator
//
//  Created by Shalev on 10/30/15.
//  Copyright © 2015 Shalev. All rights reserved.
//

import UIKit

class CalcButton: UIButton {

    @IBInspectable var myButtonType:Int = 2
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        if self.myButtonType == 0
        {
            self.backgroundColor = UIColor.redColor()
        }
        else if self.myButtonType == 1
        {
            UIColor.greenColor().setFill()
        }
        else
        {
            self.backgroundColor = UIColor.blueColor()
        }
    }

//    var text: String
//    
//    
//
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    init()
//    {
//        text = "hi"
////        UIButton.init()
//    }
//    
//    init(text: String)
//    {
////        super.init()
//        self.text = text
////        UIButton.init()
//    }

//    init(bType: Int)
//    {
//        self.myButtonType = bType
//        super.init
//    }

//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
//        self.backgroundColor = UIColor.greenColor()
        //UIColor.greenColor().setFill()
        if self.myButtonType == 0
        {
//            UIColor.init(red: 0.6, green: 0.6, blue: 0.6, alpha: 1).setFill()
            self.backgroundColor = UIColor.greenColor()
//            self.backgroundColor = UIColor.greenColor()
        }
        else if self.myButtonType == 1
        {
//            UIColor.orangeColor().setFill()
            self.backgroundColor = UIColor.orangeColor()
        }
        else if self.myButtonType == 2
        {
            UIColor.init(red: 0.43, green: 0.44, blue: 0.47, alpha: 1).setFill()
        }
    }

    

}
