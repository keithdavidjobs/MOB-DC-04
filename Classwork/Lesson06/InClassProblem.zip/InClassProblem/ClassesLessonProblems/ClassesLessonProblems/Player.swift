//
//  Player.swift
//  ClassesLessonProblems
//
//  Created by Tedi Konda on 10/12/15.
//  Copyright © 2015 Tedi Konda. All rights reserved.
//

import Foundation

struct Player
{
    var name: String
    var age: Int?
    var weight: Int?
    var gender: String?
    var height: Int?
}