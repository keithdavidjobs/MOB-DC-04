//
//  Game.swift
//  ClassesLessonProblems
//
//  Created by Shalev on 10/14/15.
//  Copyright © 2015 Tedi Konda. All rights reserved.
//

import Foundation

class Game
{
    var player1 = Player(name: "", age: 0, weight: 0, gender: "", height: 0)
    var player2 = Player(name: "", age: 0, weight: 0, gender: "", height: 0)
    
    init()
    {
    }
}